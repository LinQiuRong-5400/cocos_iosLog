import { _decorator, Component, Node, Label, v3 } from 'cc';
import { PREVIEW } from 'cc/env';
import ListView from './ListView';

const { ccclass, property } = _decorator;

class LOG_MDEL{
    
    list: any[];
    init() {
        let src_info = console.info.bind(window.console)
        let src_log = console.log.bind(window.console)
        let src_warn = console.warn.bind(window.console)
        let src_debug = console.debug.bind(window.console)
        let src_error = console.error.bind(window.console)
        
        this.list = [];
        let _logCache = function (type,arg) {
            let info: {
                index,
                type, str, list
            } = { index: this.list.length, type: type, str:"", list:[]};
            let _tempStr = ":"
            for (let ii = 0; ii < arg.length; ii++) {
                if (typeof arg[ii] == "number" || typeof arg[ii] == "string" || typeof arg[ii] == "boolean") {
                    _tempStr += arg[ii] + ":"
                } else if (typeof arg[ii] == "object") {
                    
                } else if (typeof arg[ii] == "function") {

                } else if (typeof arg[ii] == "undefined") {

                } else if (typeof arg[ii] == "bigint") {

                } else if (typeof arg[ii] == "symbol") {

                }
            }
            info.str = _tempStr;
            this.list.push(info);
        }.bind(this);

        console.info = (...arg) => {
            _logCache("info", arg)
            src_info(...arg)
        }
        console.log = (...arg) => {
            _logCache("log", arg)
            src_log(...arg)
        }
        console.warn = (...arg) => {
            _logCache("warn", arg)
            src_warn(...arg)
        }
        console.debug = (...arg) => {
            _logCache("debug", arg)
            src_debug(...arg)
        }
        console.error = (...arg) => {
            _logCache("error", arg)
            src_error(...arg)
        }
    }
}

if (window) {
    window.showDiyLogModel = false;
    if (window.showDiyLogModel) {
        window.DiyLogModel = new LOG_MDEL();
        window.DiyLogModel.init();   
    }
}
@ccclass('DiyLogView')
export class DiyLogView extends Component {
    @property(ListView)
    scrollViewComponent: ListView = null;
    @property(Node)
    moveNode: Node = null;
    DiyLogModel: LOG_MDEL = null;
    onLoad() {
        if (PREVIEW || window && window.showDiyLogModel) {
            this.DiyLogModel = window.DiyLogModel;
            this.scrollViewComponent.SetUpdateCallBack(function (item, index, info, list) {
                item.active = true;
                item.getChildByName("lab").getComponent(Label).string = info.index + "+" + info.type + info.str;
                item.getChildByName("btn")["log_index"] = info.index;
            })
            // 注册触摸移动事件
            this.moveNode.on(Node.EventType.TOUCH_MOVE, function (event) {
                // 获取当前位置
                var currentPos = event.getDelta();
                let _pos = this.node.position;
                this.node.position = v3(_pos.x + currentPos.x, _pos.y + currentPos.y, 0);
            }, this);
        } else {
            console.log("lqr...", "hide...DiyLogView");
            this.node.destroy();
        }
    }
    start() {

    }
    onCLickShowLog() {
        this.scrollViewComponent.UpdateInfoList(this.DiyLogModel.list);
    }
    onCLickToBottom() {
        this.scrollViewComponent.scrollToBottom(true);
    }
    onCLickClrarLog() {
        this.DiyLogModel.list = [];
        this.scrollViewComponent.UpdateInfoList(this.DiyLogModel.list);
    }
    onCLickShow() {
        this.node.getChildByName("main").active = !this.node.getChildByName("main").active;
        this.node.getChildByName("ScrollView").active = this.node.getChildByName("main").active;
        let lab_desc = this.node.getChildByName("ScrollView").getChildByName("lab_desc");
        lab_desc.active = false;
    }
    onCLickDetail(target) {
        let btn = target.target;
        let log_index = btn.log_index;

        let info = null;
        for (let ii = 0; ii < this.DiyLogModel.list.length; ii++) {
            let _info = this.DiyLogModel.list[ii];
            if (_info.index == log_index) {
                info = _info;
            }
        }
        if (info) {
            let lab_desc = this.node.getChildByName("ScrollView").getChildByName("lab_desc");
            lab_desc.active = true;
            lab_desc.getComponent(Label).string = info.index + "_" + info.type + info.str;;
        }
    }

    update(deltaTime: number) {
        
    }
}

